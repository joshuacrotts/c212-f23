interface Evaluable {

    Lvalue eval(Environment env);
}
